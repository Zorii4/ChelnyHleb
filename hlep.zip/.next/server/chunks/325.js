exports.id = 325;
exports.ids = [325];
exports.modules = {

/***/ 9743:
/***/ ((module) => {

// Exports
module.exports = {
	"ordersItemHeader": "OrderTitle_ordersItemHeader__mUmhd",
	"containerHeader": "OrderTitle_containerHeader__skkSk",
	"orderDescr": "OrderTitle_orderDescr__3I8bv",
	"numberOfOrder": "OrderTitle_numberOfOrder__yP59D",
	"statusWrapper": "OrderTitle_statusWrapper__1H7Xr",
	"amountDataWrapper": "OrderTitle_amountDataWrapper___mI4S",
	"amountWrapper": "OrderTitle_amountWrapper__042fF",
	"orderArrowClose": "OrderTitle_orderArrowClose__Kw3Cl",
	"orderArrowOpen": "OrderTitle_orderArrowOpen__6RXNC",
	"totalOrderAmount": "OrderTitle_totalOrderAmount__YxHWj",
	"orderDate": "OrderTitle_orderDate__VIwn4",
	"contentDefault": "OrderTitle_contentDefault__qlt5C",
	"contentActive": "OrderTitle_contentActive___ZS68",
	"bonusNumber": "OrderTitle_bonusNumber__KBVBD"
};


/***/ }),

/***/ 5030:
/***/ ((module) => {

// Exports
module.exports = {
	"puchaseDescriptionContainer": "ThisOrderDescription_puchaseDescriptionContainer__clUJi",
	"leftWrpapper": "ThisOrderDescription_leftWrpapper__30lGp",
	"puchaseItem": "ThisOrderDescription_puchaseItem__GPEZj",
	"puchaseItemTitle": "ThisOrderDescription_puchaseItemTitle__3Orhs",
	"puchaseQuantity": "ThisOrderDescription_puchaseQuantity__LQbeP",
	"puchaseAmount": "ThisOrderDescription_puchaseAmount__K_Oex",
	"deliveryAdressWrapper": "ThisOrderDescription_deliveryAdressWrapper__jBoa9",
	"deliveryAmountWrapper": "ThisOrderDescription_deliveryAmountWrapper__3kMBg",
	"addrWrapper": "ThisOrderDescription_addrWrapper__Efe9G",
	"deliveryDate": "ThisOrderDescription_deliveryDate__KWZbj",
	"deliveryDestination": "ThisOrderDescription_deliveryDestination__TaFL5",
	"puchaseItemSubTitle": "ThisOrderDescription_puchaseItemSubTitle__l7Bea",
	"puchaseItemNumber": "ThisOrderDescription_puchaseItemNumber__M8lhZ",
	"puchaseItemTotal": "ThisOrderDescription_puchaseItemTotal__huynX",
	"totalAmountTitle": "ThisOrderDescription_totalAmountTitle__hXYlg",
	"totalAmountNumber": "ThisOrderDescription_totalAmountNumber__eZYn4",
	"puchaseItemBtns": "ThisOrderDescription_puchaseItemBtns__Soa9l",
	"confirmBtn": "ThisOrderDescription_confirmBtn__3sjEh",
	"cancelBtn": "ThisOrderDescription_cancelBtn__jmvba"
};


/***/ }),

/***/ 1325:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ OrderTitle_OrderTitle)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "styled-jsx/style"
var style_ = __webpack_require__(9816);
var style_default = /*#__PURE__*/__webpack_require__.n(style_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./components/Orders/ThisOrderDescription/ThisOrderDescription.module.css
var ThisOrderDescription_module = __webpack_require__(5030);
var ThisOrderDescription_module_default = /*#__PURE__*/__webpack_require__.n(ThisOrderDescription_module);
;// CONCATENATED MODULE: ./components/Orders/ThisOrderDescription/ThisOrderDescription.jsx



const ThisOrderDescription = ({ order , isHistory  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (ThisOrderDescription_module_default()).puchaseDescriptionContainer,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: (ThisOrderDescription_module_default()).leftWrpapper,
                children: order.consist.map((item)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: (ThisOrderDescription_module_default()).puchaseItem,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                src: item.basketImg,
                                width: 94,
                                height: 66,
                                alt: ""
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (ThisOrderDescription_module_default()).puchaseItemTitle,
                                children: item.title
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (ThisOrderDescription_module_default()).puchaseQuantity,
                                children: [
                                    item.consist.length,
                                    " шт"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (ThisOrderDescription_module_default()).puchaseAmount,
                                children: [
                                    order.amount,
                                    " ₽"
                                ]
                            })
                        ]
                    }, item.id)
                )
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (ThisOrderDescription_module_default()).deliveryAdressWrapper,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                width: "15",
                                height: "15",
                                viewBox: "0 0 15 15",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M9.84519 13.3127L13.9072 2.35371C14.2052 1.54971 13.4222 0.766715 12.6182 1.06471L1.65419 5.12971C0.730187 5.47271 0.803187 6.80272 1.75819 7.04272L6.69819 8.28371L7.93119 13.2077C8.17119 14.1637 9.50219 14.2367 9.84519 13.3127V13.3127Z",
                                    stroke: "#304250",
                                    strokeWidth: "1.5",
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (ThisOrderDescription_module_default()).addrWrapper,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        className: (ThisOrderDescription_module_default()).deliveryDate,
                                        children: [
                                            "Доставка ",
                                            order.data
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (ThisOrderDescription_module_default()).deliveryDestination,
                                        children: order.address
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (ThisOrderDescription_module_default()).deliveryAmountWrapper,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: (ThisOrderDescription_module_default()).puchaseItem,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (ThisOrderDescription_module_default()).puchaseItemSubTitle,
                                            children: "Товары"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: (ThisOrderDescription_module_default()).puchaseItemNumber,
                                            children: [
                                                order.amount,
                                                " ₽"
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: (ThisOrderDescription_module_default()).puchaseItem,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (ThisOrderDescription_module_default()).puchaseItemSubTitle,
                                            children: "Доставка"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: (ThisOrderDescription_module_default()).puchaseItemNumber,
                                            children: [
                                                order.amount,
                                                " ₽"
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: (ThisOrderDescription_module_default()).puchaseItem,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (ThisOrderDescription_module_default()).puchaseItemSubTitle,
                                            children: "Баллы за покупку"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: (ThisOrderDescription_module_default()).puchaseItemNumber,
                                            children: [
                                                "11\xa0",
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                    width: "14",
                                                    height: "14",
                                                    viewBox: "0 0 14 14",
                                                    fill: "none",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                            fillRule: "evenodd",
                                                            clipRule: "evenodd",
                                                            d: "M3.84565 6.82663C2.91418 5.88819 1.78317 5.2819 0.445312 5.01258C1.22352 2.29316 3.55548 0.276637 6.35857 0.00743006C4.37598 2.1875 3.43872 4.75025 3.84565 6.82663ZM7.55809 0C10.4251 0.237322 12.7704 2.28021 13.5564 4.99417C12.1958 5.24855 11.0186 5.87074 10.0635 6.82663C10.5485 4.76496 9.62598 2.1875 7.55809 0Z",
                                                            fill: "#B0BCC9"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                            fillRule: "evenodd",
                                                            clipRule: "evenodd",
                                                            d: "M0.178928 5.46476C-0.813305 9.71759 2.44754 13.9054 6.83431 14C7.0296 9.85152 3.85596 6.79014 0.178928 5.46476ZM4.29067 5.92393C4.29024 3.71579 5.5861 1.67294 6.91797 0C6.93121 0 6.93121 0 6.94255 0C8.30337 1.6384 9.69935 3.72104 9.69935 5.92393C9.69935 7.46195 8.66657 9.31813 6.93121 9.31813C5.2164 9.31813 4.29067 7.40691 4.29067 5.92393ZM7.15571 14C11.5183 13.9031 14.8334 9.71158 13.8147 5.46476C10.1314 6.77475 6.95997 9.85645 7.15571 14Z",
                                                            fill: "#B0BCC9"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: (ThisOrderDescription_module_default()).puchaseItemTotal,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (ThisOrderDescription_module_default()).totalAmountTitle,
                                            children: "Итого"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: (ThisOrderDescription_module_default()).totalAmountNumber,
                                            children: [
                                                order.amount,
                                                " ₽"
                                            ]
                                        })
                                    ]
                                }),
                                !isHistory ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: (ThisOrderDescription_module_default()).puchaseItemBtns,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: (ThisOrderDescription_module_default()).confirmBtn,
                                            children: "Оплатить"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: (ThisOrderDescription_module_default()).cancelBtn,
                                            children: "Отменить"
                                        })
                                    ]
                                }) : /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: (ThisOrderDescription_module_default()).puchaseItemBtns,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: (ThisOrderDescription_module_default()).confirmBtn,
                                        children: "Повторить заказ"
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const ThisOrderDescription_ThisOrderDescription = (ThisOrderDescription);

// EXTERNAL MODULE: ./components/Orders/OrderTitle/OrderTitle.module.css
var OrderTitle_module = __webpack_require__(9743);
var OrderTitle_module_default = /*#__PURE__*/__webpack_require__.n(OrderTitle_module);
;// CONCATENATED MODULE: ./components/Orders/OrderTitle/OrderTitle.jsx





const OrderTitle = ({ orders , isHistory  })=>{
    const elemRef = (0,external_react_.useRef)();
    const { /*#__PURE__*/ 0: activeIndex , 1: setActiveIndex  } = (0,external_react_.useState)(null);
    const onHandleVisible = (idx)=>{
        idx === activeIndex ? setActiveIndex(null) : setActiveIndex(idx);
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx("ul", {
        children: orders.map((order, index)=>{
            var ref;
            /*#__PURE__*/ return (0,jsx_runtime_.jsxs)("li", {
                className: (OrderTitle_module_default()).ordersItemHeader,
                onClick: ()=>onHandleVisible(index)
                ,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (OrderTitle_module_default()).containerHeader,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (OrderTitle_module_default()).orderDescr,
                                        children: "Номер заказа"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (OrderTitle_module_default()).statusWrapper,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: (OrderTitle_module_default()).numberOfOrder,
                                                children: [
                                                    "№ ",
                                                    order.id
                                                ]
                                            }),
                                            !isHistory && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: style_default().dynamic([
                                                    [
                                                        "f5bb524e72c21395",
                                                        [
                                                            order.status === 'В работе' ? '#61A430;' : order.status === 'Отменён' ? '#E50029;' : '#fff2cc;',
                                                            order.status === 'Ожидает оплаты' ? '#F8BD00;' : '#FFFFFF;'
                                                        ]
                                                    ]
                                                ]),
                                                children: [
                                                    order.status,
                                                    jsx_runtime_.jsx((style_default()), {
                                                        id: "f5bb524e72c21395",
                                                        dynamic: [
                                                            order.status === 'В работе' ? '#61A430;' : order.status === 'Отменён' ? '#E50029;' : '#fff2cc;',
                                                            order.status === 'Ожидает оплаты' ? '#F8BD00;' : '#FFFFFF;'
                                                        ],
                                                        children: `p.__jsx-style-dynamic-selector{background-color: ${order.status === 'В работе' ? '#61A430;' : order.status === 'Отменён' ? '#E50029;' : '#fff2cc;'}
                                            font-family: 'Golos';
font-size:16px;
line-height:120%;
color:${order.status === 'Ожидает оплаты' ? '#F8BD00;' : '#FFFFFF;'};
border-radius:4px;
padding:3px;
height:20px;
display:-webkit-box;
display:-webkit-flex;
display:-ms-flexbox;
display:flex;
-webkit-align-items:center;
-webkit-box-align:center;
-ms-flex-align:center;
align-items:center}`
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (OrderTitle_module_default()).amountDataWrapper,
                                children: [
                                    isHistory && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: (OrderTitle_module_default()).orderDescr,
                                                children: "Начислено"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                        width: "18",
                                                        height: "18",
                                                        viewBox: "0 0 18 18",
                                                        fill: "none",
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                                fillRule: "evenodd",
                                                                clipRule: "evenodd",
                                                                d: "M4.94218 8.7771C3.74457 7.57053 2.29042 6.79101 0.570312 6.44474C1.57087 2.94835 4.5691 0.355677 8.17308 0.00955293C5.62402 2.8125 4.41898 6.10746 4.94218 8.7771ZM9.71531 0C13.4015 0.305128 16.4168 2.9317 17.4275 6.42108C15.678 6.74813 14.1645 7.54809 12.9365 8.7771C13.5601 6.12638 12.374 2.8125 9.71531 0Z",
                                                                fill: "#61A430"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                                fillRule: "evenodd",
                                                                clipRule: "evenodd",
                                                                d: "M0.23005 7.02612C-1.04568 12.4941 3.14683 17.8783 8.78696 18C9.03806 12.6662 4.95767 8.73018 0.23005 7.02612ZM5.51657 7.61648C5.51602 4.77744 7.18212 2.15092 8.89453 0C8.91156 0 8.91156 0 8.92614 0C10.6758 2.10652 12.4706 4.7842 12.4706 7.61648C12.4706 9.59393 11.1427 11.9805 8.91156 11.9805C6.70679 11.9805 5.51657 9.52317 5.51657 7.61648ZM9.2002 18C14.8092 17.8755 19.0715 12.4863 17.7617 7.02612C13.0261 8.7104 8.94853 12.6726 9.2002 18Z",
                                                                fill: "#61A430"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: (OrderTitle_module_default()).bonusNumber,
                                                        children: [
                                                            " +",
                                                            order.bonus
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (OrderTitle_module_default()).amountWrapper,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: (OrderTitle_module_default()).orderDescr,
                                                children: "Итоговая сумма"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: (OrderTitle_module_default()).totalOrderAmount,
                                                children: [
                                                    order.amount,
                                                    " ₽"
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            !isHistory ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: (OrderTitle_module_default()).orderDescr,
                                                children: "Запланирована доставка"
                                            }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: (OrderTitle_module_default()).orderDescr,
                                                children: "Дата доставки"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: (OrderTitle_module_default()).orderDate,
                                                children: order.data
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: activeIndex === index ? (OrderTitle_module_default()).orderArrowClose : (OrderTitle_module_default()).orderArrowOpen,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                            width: "13",
                                            height: "9",
                                            viewBox: "0 0 13 9",
                                            fill: "none",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                d: "M1 1.75L6.5 7.25L12 1.75",
                                                stroke: "#B0BCC9",
                                                strokeWidth: "2",
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round"
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        style: {
                            maxHeight: `${(ref = elemRef.current) === null || ref === void 0 ? void 0 : ref.offsetHeight}px`
                        },
                        className: `${(OrderTitle_module_default()).contentDefault} ${activeIndex === index ? (OrderTitle_module_default()).contentActive : null}`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            ref: elemRef,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ThisOrderDescription_ThisOrderDescription, {
                                order: order,
                                isHistory: isHistory
                            })
                        })
                    })
                ]
            }, order.id);
        })
    }));
};
/* harmony default export */ const OrderTitle_OrderTitle = (OrderTitle);


/***/ })

};
;