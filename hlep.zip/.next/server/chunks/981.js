exports.id = 981;
exports.ids = [981];
exports.modules = {

/***/ 7695:
/***/ ((module) => {

// Exports
module.exports = {
	"discountLikeContainer": "GoodsCard_discountLikeContainer__UIMPD",
	"likeButton": "GoodsCard_likeButton__Y__pc",
	"discountProcent": "GoodsCard_discountProcent__hjbed",
	"imageContainer": "GoodsCard_imageContainer__9hY0c",
	"goodCardTitle": "GoodsCard_goodCardTitle__poP1j",
	"goodOldPrice": "GoodsCard_goodOldPrice__FwJib",
	"goodNewPiceWrapper": "GoodsCard_goodNewPiceWrapper__QwNQB",
	"goodNewPriceRub": "GoodsCard_goodNewPriceRub__4PeZA",
	"goodNewPriceKop": "GoodsCard_goodNewPriceKop__zp6kw",
	"goodBasketContainer": "GoodsCard_goodBasketContainer__vztop",
	"orderButton": "GoodsCard_orderButton__b0hbZ",
	"bottomWrapper": "GoodsCard_bottomWrapper__H_Sik",
	"rateNumber": "GoodsCard_rateNumber__RxZbR"
};


/***/ }),

/***/ 6981:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _types_goods__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5784);
/* harmony import */ var _styles_GoodsCard_module_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7695);
/* harmony import */ var _styles_GoodsCard_module_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_styles_GoodsCard_module_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _FAKE_API_goods__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(294);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _store_reducers_basketReducer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5609);
/* harmony import */ var _store_reducers_goodsReducer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5804);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_9__);











const GoodCard = ({ good: good1  })=>{
    const [intiger, float] = good1.newprice.toString().split('.');
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useDispatch)();
    const isMobile = (0,react_responsive__WEBPACK_IMPORTED_MODULE_9__.useMediaQuery)({
        query: '(max-width: 480px)'
    });
    const handleAddToBasket = (good)=>{
        dispatch((0,_store_reducers_basketReducer__WEBPACK_IMPORTED_MODULE_7__/* .addToBasket */ .H)(good));
    };
    const handleAddFav = (good)=>{
        return dispatch((0,_store_reducers_goodsReducer__WEBPACK_IMPORTED_MODULE_8__/* .addFavorities */ .bz)(good));
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_GoodsCard_module_css__WEBPACK_IMPORTED_MODULE_10___default().cardWrapper),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_GoodsCard_module_css__WEBPACK_IMPORTED_MODULE_10___default().discountLikeContainer),
                children: [
                    good1.discount ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_GoodsCard_module_css__WEBPACK_IMPORTED_MODULE_10___default().discountProcent),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                width: "10",
                                height: "3",
                                viewBox: "0 0 10 3",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M-0.0012579 0.984474L9.96484 0.984474V2.4082L-0.0012579 2.4082V0.984474Z",
                                    fill: "white"
                                })
                            }),
                            good1.discount,
                            "%"
                        ]
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: (_styles_GoodsCard_module_css__WEBPACK_IMPORTED_MODULE_10___default().likeButton),
                        onClick: ()=>handleAddFav(good1)
                        ,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                            width: "18",
                            height: "16",
                            viewBox: "0 0 18 16",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: good1.like ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M12.08 1.33203C14.7258 1.33203 16.5 3.81536 16.5 6.12786C16.5 10.822 9.13417 14.6654 9 14.6654C8.86583 14.6654 1.5 10.822 1.5 6.12786C1.5 3.81536 3.27417 1.33203 5.92 1.33203C7.4325 1.33203 8.42583 2.0862 9 2.75786C9.57417 2.0862 10.5675 1.33203 12.08 1.33203Z",
                                fill: "#E50029",
                                stroke: "#E50029",
                                strokeWidth: "1.5",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M12.08 1.33203C14.7258 1.33203 16.5 3.81536 16.5 6.12786C16.5 10.822 9.13417 14.6654 9 14.6654C8.86583 14.6654 1.5 10.822 1.5 6.12786C1.5 3.81536 3.27417 1.33203 5.92 1.33203C7.4325 1.33203 8.42583 2.0862 9 2.75786C9.57417 2.0862 10.5675 1.33203 12.08 1.33203Z",
                                stroke: "#B3BFCC",
                                strokeWidth: "1.5",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                href: `/catalog/${good1.category}/${good1.subCategory}/${good1.finalCategory}/${good1.id}`,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_styles_GoodsCard_module_css__WEBPACK_IMPORTED_MODULE_10___default().imageContainer),
                            children: isMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                width: 150,
                                height: 104,
                                src: good1.image,
                                alt: ""
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                width: 240,
                                height: 166,
                                src: good1.image,
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_styles_GoodsCard_module_css__WEBPACK_IMPORTED_MODULE_10___default().rateNumber),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                    width: "12",
                                    height: "11",
                                    viewBox: "0 0 12 11",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M5.99984 0.666504L7.72401 3.62672L11.0721 4.35175L8.7896 6.90629L9.13469 10.3146L5.99984 8.93317L2.86498 10.3146L3.21007 6.90629L0.927536 4.35175L4.27567 3.62672L5.99984 0.666504Z",
                                        fill: "#FDC000"
                                    })
                                }),
                                good1.rate
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_GoodsCard_module_css__WEBPACK_IMPORTED_MODULE_10___default().bottomWrapper),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                        className: (_styles_GoodsCard_module_css__WEBPACK_IMPORTED_MODULE_10___default().goodCardTitle),
                        children: good1.title
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_GoodsCard_module_css__WEBPACK_IMPORTED_MODULE_10___default().goodOldPrice),
                                children: [
                                    good1.oldprice,
                                    "₽"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_GoodsCard_module_css__WEBPACK_IMPORTED_MODULE_10___default().goodBasketContainer),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_GoodsCard_module_css__WEBPACK_IMPORTED_MODULE_10___default().goodNewPiceWrapper),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_styles_GoodsCard_module_css__WEBPACK_IMPORTED_MODULE_10___default().goodNewPriceRub),
                                                children: intiger
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_styles_GoodsCard_module_css__WEBPACK_IMPORTED_MODULE_10___default().goodNewPriceKop),
                                                children: [
                                                    float,
                                                    "₽"
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: (_styles_GoodsCard_module_css__WEBPACK_IMPORTED_MODULE_10___default().orderButton),
                                        onClick: ()=>handleAddToBasket(good1)
                                        ,
                                        children: isMobile ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                            width: "20",
                                            height: "20",
                                            viewBox: "0 0 20 20",
                                            fill: "none",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    d: "M4.97388 5.51953L4.41805 3.01953H2.81055",
                                                    stroke: "white",
                                                    strokeWidth: "1.5",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    fillRule: "evenodd",
                                                    clipRule: "evenodd",
                                                    d: "M6.44294 12.3612L4.97461 5.51953H15.5229C16.0538 5.51953 16.4488 6.0087 16.3379 6.52786L15.0863 12.3612C15.0038 12.7454 14.6646 13.0195 14.2713 13.0195H7.25711C6.86461 13.0195 6.52544 12.7454 6.44294 12.3612Z",
                                                    stroke: "white",
                                                    strokeWidth: "1.5",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    d: "M14.3984 15.7496C14.15 15.7496 13.9484 15.9512 13.9508 16.1996C13.9508 16.448 14.1524 16.6496 14.4008 16.6496C14.6492 16.6496 14.8508 16.448 14.8508 16.1996C14.8496 15.9512 14.648 15.7496 14.3984 15.7496",
                                                    stroke: "white",
                                                    strokeWidth: "1.5",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    d: "M7.56305 15.7496C7.31465 15.7496 7.11305 15.9512 7.11545 16.1996C7.11425 16.448 7.31585 16.6496 7.56425 16.6496C7.81265 16.6496 8.01425 16.448 8.01425 16.1996C8.01425 15.9512 7.81265 15.7496 7.56305 15.7496",
                                                    stroke: "white",
                                                    strokeWidth: "1.5",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                })
                                            ]
                                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                                    width: "27",
                                                    height: "27",
                                                    viewBox: "0 0 27 27",
                                                    fill: "none",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                            d: "M6.71493 7.45117L5.96456 4.07617H3.79443",
                                                            stroke: "white",
                                                            strokeWidth: "2",
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                            fillRule: "evenodd",
                                                            clipRule: "evenodd",
                                                            d: "M8.69807 16.6874L6.71582 7.45117H20.9561C21.6727 7.45117 22.2059 8.11155 22.0563 8.81242L20.3666 16.6874C20.2552 17.2061 19.7973 17.5762 19.2663 17.5762H9.7972C9.26732 17.5762 8.80945 17.2061 8.69807 16.6874Z",
                                                            stroke: "white",
                                                            strokeWidth: "2",
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                            d: "M19.4376 21.2621C19.1023 21.2621 18.8301 21.5342 18.8334 21.8696C18.8334 22.2049 19.1055 22.4771 19.4409 22.4771C19.7762 22.4771 20.0484 22.2049 20.0484 21.8696C20.0467 21.5342 19.7746 21.2621 19.4376 21.2621",
                                                            stroke: "white",
                                                            strokeWidth: "2",
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                            d: "M10.2099 21.2621C9.87459 21.2621 9.60243 21.5342 9.60567 21.8696C9.60405 22.2049 9.87621 22.4771 10.2115 22.4771C10.5469 22.4771 10.819 22.2049 10.819 21.8696C10.819 21.5342 10.5469 21.2621 10.2099 21.2621",
                                                            stroke: "white",
                                                            strokeWidth: "2",
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                                    width: "28",
                                                    height: "28",
                                                    viewBox: "0 0 28 28",
                                                    fill: "none",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                            d: "M16.0002 6.6665V17.3332",
                                                            stroke: "white",
                                                            strokeWidth: "1.5",
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                            d: "M21.3332 12.0002H10.6665",
                                                            stroke: "white",
                                                            strokeWidth: "1.5",
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GoodCard);


/***/ }),

/***/ 5784:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony export GoodsActionTypes */
var GoodsActionTypes;
(function(GoodsActionTypes) {
    GoodsActionTypes["FETCH_GOODS_SUCCESS"] = "FETCH_GOODS_SUCCESS";
    GoodsActionTypes["FETCH_GOODS_ERROR"] = "FETCH_GOODS_ERROR";
    GoodsActionTypes["FETCH_GOOD_FROM_CATEGORY_SUCCESS"] = "FETCH_GOOD_FROM_CATEGORY_SUCCESS";
    GoodsActionTypes["FETCH_GOOD_FROM_CATEGORY_ERROR"] = "FETCH_GOOD_FROM_CATEGORY_ERROR";
})(GoodsActionTypes || (GoodsActionTypes = {}));


/***/ })

};
;