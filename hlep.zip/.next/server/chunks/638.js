exports.id = 638;
exports.ids = [638];
exports.modules = {

/***/ 1048:
/***/ ((module) => {

// Exports
module.exports = {
	"cardList": "WeeksNewBanner_cardList__LXwiy",
	"container": "WeeksNewBanner_container__sH9Ix",
	"leftWrapper": "WeeksNewBanner_leftWrapper__BWU36",
	"bannerTitle": "WeeksNewBanner_bannerTitle__DaNCW",
	"cardWrapper": "WeeksNewBanner_cardWrapper__C0PJm",
	"navBtnContainer": "WeeksNewBanner_navBtnContainer__pArQW",
	"swiperBtn": "WeeksNewBanner_swiperBtn__A2ITh"
};


/***/ }),

/***/ 5521:
/***/ ((module) => {

// Exports
module.exports = {
	"discountLikeContainer": "LittleGoodCard_discountLikeContainer__ZZ_tP",
	"discountProcent": "LittleGoodCard_discountProcent__mtAF6",
	"goodCardTitle": "LittleGoodCard_goodCardTitle__Uqk6T",
	"goodOldPrice": "LittleGoodCard_goodOldPrice__02wLu",
	"goodNewPiceWrapper": "LittleGoodCard_goodNewPiceWrapper__oqMbJ",
	"goodNewPriceRub": "LittleGoodCard_goodNewPriceRub__WnyyY",
	"goodNewPriceKop": "LittleGoodCard_goodNewPriceKop__lrBtp",
	"goodBasketContainer": "LittleGoodCard_goodBasketContainer__A4Uzt",
	"orderButton": "LittleGoodCard_orderButton__8iYGa",
	"likeButton": "LittleGoodCard_likeButton__Y2gs4",
	"bottomWrapper": "LittleGoodCard_bottomWrapper__6xTiI"
};


/***/ }),

/***/ 4552:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_LittleGoodCard_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5521);
/* harmony import */ var _styles_LittleGoodCard_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_LittleGoodCard_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_reducers_goodsReducer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5804);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_4__);






const LittleGoodCard = ({ good: good1  })=>{
    const isMobile = (0,react_responsive__WEBPACK_IMPORTED_MODULE_4__.useMediaQuery)({
        query: '(max-width: 480px)'
    });
    const [intiger, float] = good1.newprice.toString().split('.');
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();
    const handleAddFav = (good)=>{
        return dispatch((0,_store_reducers_goodsReducer__WEBPACK_IMPORTED_MODULE_3__/* .addFavorities */ .bz)(good));
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_LittleGoodCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().discountLikeContainer),
                children: [
                    good1.discount ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_LittleGoodCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().discountProcent),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                width: "10",
                                height: "3",
                                viewBox: "0 0 10 3",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    fillRule: "evenodd",
                                    clipRule: "evenodd",
                                    d: "M-0.0012579 0.984474L9.96484 0.984474V2.4082L-0.0012579 2.4082V0.984474Z",
                                    fill: "white"
                                })
                            }),
                            good1.discount,
                            "%"
                        ]
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: (_styles_LittleGoodCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().likeButton),
                        onClick: ()=>handleAddFav(good1)
                        ,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                            width: "18",
                            height: "16",
                            viewBox: "0 0 18 16",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: good1.like ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M12.08 1.33203C14.7258 1.33203 16.5 3.81536 16.5 6.12786C16.5 10.822 9.13417 14.6654 9 14.6654C8.86583 14.6654 1.5 10.822 1.5 6.12786C1.5 3.81536 3.27417 1.33203 5.92 1.33203C7.4325 1.33203 8.42583 2.0862 9 2.75786C9.57417 2.0862 10.5675 1.33203 12.08 1.33203Z",
                                fill: "#E50029",
                                stroke: "#E50029",
                                strokeWidth: "1.5",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M12.08 1.33203C14.7258 1.33203 16.5 3.81536 16.5 6.12786C16.5 10.822 9.13417 14.6654 9 14.6654C8.86583 14.6654 1.5 10.822 1.5 6.12786C1.5 3.81536 3.27417 1.33203 5.92 1.33203C7.4325 1.33203 8.42583 2.0862 9 2.75786C9.57417 2.0862 10.5675 1.33203 12.08 1.33203Z",
                                stroke: "#B3BFCC",
                                strokeWidth: "1.5",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            })
                        })
                    })
                ]
            }),
            isMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                src: good1.image,
                width: 98,
                height: 68,
                alt: ""
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                src: good1.image,
                width: 170,
                height: 113,
                alt: ""
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_LittleGoodCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().bottomWrapper),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                        className: (_styles_LittleGoodCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().goodCardTitle),
                        children: good1.title
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_LittleGoodCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().goodOldPrice),
                        children: [
                            good1.oldprice,
                            "₽"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_LittleGoodCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().goodBasketContainer),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_LittleGoodCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().goodNewPiceWrapper),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_LittleGoodCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().goodNewPriceRub),
                                        children: intiger
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_styles_LittleGoodCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().goodNewPriceKop),
                                        children: [
                                            float,
                                            "₽"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: (_styles_LittleGoodCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().orderButton),
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                    width: "20",
                                    height: "20",
                                    viewBox: "0 0 20 20",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            d: "M4.97388 5.51953L4.41805 3.01953H2.81055",
                                            stroke: "white",
                                            strokeWidth: "1.5",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            fillRule: "evenodd",
                                            clipRule: "evenodd",
                                            d: "M6.44294 12.3612L4.97461 5.51953H15.5229C16.0538 5.51953 16.4488 6.0087 16.3379 6.52786L15.0863 12.3612C15.0038 12.7454 14.6646 13.0195 14.2713 13.0195H7.25711C6.86461 13.0195 6.52544 12.7454 6.44294 12.3612Z",
                                            stroke: "white",
                                            strokeWidth: "1.5",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            d: "M14.3984 15.7496C14.15 15.7496 13.9484 15.9512 13.9508 16.1996C13.9508 16.448 14.1524 16.6496 14.4008 16.6496C14.6492 16.6496 14.8508 16.448 14.8508 16.1996C14.8496 15.9512 14.648 15.7496 14.3984 15.7496",
                                            stroke: "white",
                                            strokeWidth: "1.5",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            d: "M7.56305 15.7496C7.31465 15.7496 7.11305 15.9512 7.11545 16.1996C7.11425 16.448 7.31585 16.6496 7.56425 16.6496C7.81265 16.6496 8.01425 16.448 8.01425 16.1996C8.01425 15.9512 7.81265 15.7496 7.56305 15.7496",
                                            stroke: "white",
                                            strokeWidth: "1.5",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LittleGoodCard);


/***/ }),

/***/ 8638:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3015);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3877);
/* harmony import */ var _hooks_useTypeSelector__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6529);
/* harmony import */ var _WeeksNewBanner_module_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1048);
/* harmony import */ var _WeeksNewBanner_module_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_WeeksNewBanner_module_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _LittleGoodCard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4552);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_2__, swiper__WEBPACK_IMPORTED_MODULE_3__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_2__, swiper__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const WeeksNewBanner = ()=>{
    // const {goods} = useTypedSelector(state => state.goods)  
    const navigationPrevRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const navigationNextRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const { goods  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.marketGoods
    );
    const isMediumScreen = (0,react_responsive__WEBPACK_IMPORTED_MODULE_7__.useMediaQuery)({
        query: '(max-width: 1024px)'
    });
    const isSmallScreen = (0,react_responsive__WEBPACK_IMPORTED_MODULE_7__.useMediaQuery)({
        query: '(max-width: 768px)'
    });
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_WeeksNewBanner_module_css__WEBPACK_IMPORTED_MODULE_8___default().container),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_WeeksNewBanner_module_css__WEBPACK_IMPORTED_MODULE_8___default().leftWrapper),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_WeeksNewBanner_module_css__WEBPACK_IMPORTED_MODULE_8___default().bannerTitle),
                        children: [
                            " Новинки",
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    " \xa0",
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                        width: "64",
                                        height: "20",
                                        viewBox: "0 0 64 20",
                                        fill: "none",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                d: "M2 9.69008C12.5882 20.77 21.4118 20.77 31.6011 9.69008C40.8235 -0.56335 51.8529 -0.563365 62 9.69008",
                                                stroke: "white",
                                                strokeWidth: "4",
                                                strokeLinecap: "round"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                d: "M2 9.69008C12.5882 20.77 21.4118 20.77 31.6011 9.69008C40.8235 -0.56335 51.8529 -0.563365 62 9.69008",
                                                stroke: "#FEFEFE",
                                                strokeWidth: "4",
                                                strokeLinecap: "round"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            " \xa0 этой недели"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_WeeksNewBanner_module_css__WEBPACK_IMPORTED_MODULE_8___default().navBtnContainer),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_WeeksNewBanner_module_css__WEBPACK_IMPORTED_MODULE_8___default().swiperBtn),
                                ref: navigationPrevRef,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                    width: "6",
                                    height: "14",
                                    viewBox: "0 0 6 14",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M5 13L1.3698 7.5547C1.14587 7.2188 1.14587 6.7812 1.3698 6.4453L5 1",
                                        stroke: "white",
                                        strokeWidth: "1.5",
                                        strokeLinecap: "round"
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_WeeksNewBanner_module_css__WEBPACK_IMPORTED_MODULE_8___default().swiperBtn),
                                ref: navigationNextRef,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                    width: "6",
                                    height: "14",
                                    viewBox: "0 0 6 14",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M1 1L4.6302 6.4453C4.85413 6.7812 4.85413 7.2188 4.6302 7.5547L1 13",
                                        stroke: "white",
                                        strokeWidth: "1.5",
                                        strokeLinecap: "round"
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: (_WeeksNewBanner_module_css__WEBPACK_IMPORTED_MODULE_8___default().cardWrapper),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.Swiper, {
                    slidesPerView: isSmallScreen ? 2 : isMediumScreen ? 3 : 4,
                    spaceBetween: 30,
                    grabCursor: true,
                    modules: [
                        swiper__WEBPACK_IMPORTED_MODULE_3__.Navigation
                    ],
                    navigation: {
                        prevEl: navigationPrevRef.current,
                        nextEl: navigationNextRef.current
                    },
                    onBeforeInit: (swiper)=>{
                        swiper.params.navigation.prevEl = navigationPrevRef.current;
                        swiper.params.navigation.nextEl = navigationNextRef.current;
                    },
                    children: goods.map((item)=>item.new && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.SwiperSlide, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_WeeksNewBanner_module_css__WEBPACK_IMPORTED_MODULE_8___default().cardList),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LittleGoodCard__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    good: item
                                })
                            }, item.id)
                        })
                    )
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WeeksNewBanner);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;