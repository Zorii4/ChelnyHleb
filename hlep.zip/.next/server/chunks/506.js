"use strict";
exports.id = 506;
exports.ids = [506];
exports.modules = {

/***/ 5609:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ addToBasket),
/* harmony export */   "lH": () => (/* binding */ goodInBasketReducer)
/* harmony export */ });
/* unused harmony export goodInBasketSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5648);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__);


const initialState = {
    goodInBasket: [],
    totalQuantity: 0,
    totalAmount: 0
};
const goodInBasketSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "goodInBasket",
    initialState,
    reducers: {
        addToBasket (state, action) {
            const itemIndex = state.goodInBasket.findIndex((item)=>item.id === action.payload.id
            );
            if (itemIndex >= 0) {
                state.goodInBasket[itemIndex].quantity += 1;
            } else {
                const tempGood = {
                    ...action.payload,
                    quantity: 1
                };
                state.goodInBasket.push(tempGood);
            }
        }
    },
    extraReducers: {
        [next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__.HYDRATE]: (state, action)=>{
            console.log('HYDRATE', state, action.payload);
            return {
                ...state,
                ...action.payload.subject
            };
        }
    }
});
const { addToBasket  } = goodInBasketSlice.actions;
const goodInBasketReducer = goodInBasketSlice.reducer;


/***/ }),

/***/ 5804:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "bz": () => (/* binding */ addFavorities),
/* harmony export */   "uf": () => (/* binding */ marketGoodsReducer)
/* harmony export */ });
/* unused harmony export marketGoods */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5648);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _FAKE_API_goods__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(294);



const initialState = {
    goods: (0,_FAKE_API_goods__WEBPACK_IMPORTED_MODULE_2__/* .fetchAllGoods */ .fC)()
};
const marketGoods = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "goodsInMarked",
    initialState,
    reducers: {
        addFavorities (state, action) {
            const newId = action.payload.id;
            let changedGood = state.goods.find((item)=>item.id === newId
            );
            changedGood.like = !changedGood.like;
            return state;
        },
        fetchAllGoods (state) {
            return state;
        }
    },
    extraReducers: {
        [next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__.HYDRATE]: (state, action)=>{
            console.log('HYDRATE', state, action.payload);
            return {
                ...state,
                ...action.payload.subject
            };
        }
    }
});
const { addFavorities  } = marketGoods.actions;
const marketGoodsReducer = marketGoods.reducer;


/***/ })

};
;