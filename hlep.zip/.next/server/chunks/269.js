exports.id = 269;
exports.ids = [269];
exports.modules = {

/***/ 3950:
/***/ ((module) => {

// Exports
module.exports = {
	"catList": "CategoriesCard_catList__uaVAw",
	"catLink": "CategoriesCard_catLink__jCMPu",
	"catTitle": "CategoriesCard_catTitle__x3Q72"
};


/***/ }),

/***/ 2635:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks_useTypeSelector__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6529);
/* harmony import */ var _FAKE_API_goods__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(294);
/* harmony import */ var _CategoriesCard_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3950);
/* harmony import */ var _CategoriesCard_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_CategoriesCard_module_css__WEBPACK_IMPORTED_MODULE_6__);







const CategoriesCard = ({ isCatalog  })=>{
    // const {categories} = useTypedSelector(state => state.categories)
    const { /*#__PURE__*/ 0: categories , 1: setCategories  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setCategories((0,_FAKE_API_goods__WEBPACK_IMPORTED_MODULE_5__/* .fetchAllCategories */ .eq)());
    }, []);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
        className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default().dynamic([
            [
                "d12ffec3c40bb4e1",
                [
                    isCatalog ? '372px' : '347px',
                    isCatalog ? '325px' : '372px'
                ]
            ]
        ]) + " " + ((_CategoriesCard_module_css__WEBPACK_IMPORTED_MODULE_6___default().catList) || ""),
        children: [
            categories.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    style: {
                        backgroundImage: `url(${item.background})`
                    },
                    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default().dynamic([
                        [
                            "d12ffec3c40bb4e1",
                            [
                                isCatalog ? '372px' : '347px',
                                isCatalog ? '325px' : '372px'
                            ]
                        ]
                    ]),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                        href: `/catalog/${item.category}`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default().dynamic([
                                [
                                    "d12ffec3c40bb4e1",
                                    [
                                        isCatalog ? '372px' : '347px',
                                        isCatalog ? '325px' : '372px'
                                    ]
                                ]
                            ]) + " " + ((_CategoriesCard_module_css__WEBPACK_IMPORTED_MODULE_6___default().catLink) || ""),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default().dynamic([
                                    [
                                        "d12ffec3c40bb4e1",
                                        [
                                            isCatalog ? '372px' : '347px',
                                            isCatalog ? '325px' : '372px'
                                        ]
                                    ]
                                ]) + " " + ((_CategoriesCard_module_css__WEBPACK_IMPORTED_MODULE_6___default().catTitle) || ""),
                                children: item.title
                            })
                        })
                    })
                }, item.id)
            ),
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "d12ffec3c40bb4e1",
                dynamic: [
                    isCatalog ? '372px' : '347px',
                    isCatalog ? '325px' : '372px'
                ],
                children: `li.__jsx-style-dynamic-selector{width:${isCatalog ? '372px' : '347px'};
height:187px;
background-size:cover;
background-repeat:no-repeat;
border-radius:12px;
margin-bottom:12px}
@media (max-width:1280px) {li.__jsx-style-dynamic-selector{width:${isCatalog ? '325px' : '372px'}}}
@media (max-width:1024px) {li.__jsx-style-dynamic-selector{width:320px;
height:174px}}
@media (max-width:768px) {li.__jsx-style-dynamic-selector{width:238px;
height:150px}}`
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategoriesCard);


/***/ }),

/***/ 2598:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _FAKE_API_goods__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(294);





const CategoriesCardMobile = ()=>{
    const { /*#__PURE__*/ 0: categories , 1: setCategories  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setCategories((0,_FAKE_API_goods__WEBPACK_IMPORTED_MODULE_4__/* .fetchAllCategories */ .eq)());
    }, []);
    if (!categories) return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
        children: "loading..."
    }));
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
        className: "jsx-319a8f7705b11ab1",
        children: [
            categories.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    style: {
                        backgroundImage: `url(${item.backgroundmobile})`
                    },
                    className: "jsx-319a8f7705b11ab1",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                        href: `/catalog/${item.category}`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            className: "jsx-319a8f7705b11ab1",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "jsx-319a8f7705b11ab1",
                                children: item.title
                            })
                        })
                    })
                }, item.id)
            ),
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "319a8f7705b11ab1",
                children: "ul.jsx-319a8f7705b11ab1{display:-webkit-box;\ndisplay:-webkit-flex;\ndisplay:-ms-flexbox;\ndisplay:flex;\nflex-wrap:wrap;\ngap:0 15px}\nli.jsx-319a8f7705b11ab1{width:140px;\nheight:140px;\nbackground-size:cover;\nbackground-repeat:no-repeat;\nborder-radius:8px;\nmargin-bottom:12px}\na.jsx-319a8f7705b11ab1{display:block;\nwidth:inherit;\nheight:inherit;\npadding-left:16px;\npadding-top:14px;\npadding-right:10px}\nh3.jsx-319a8f7705b11ab1{font-family:'Din';\nfont-style:normal;\nfont-weight:400;\nfont-size:16px;\nline-height:120%;\nletter-spacing:-0.02em;\ncolor:#304250}\n@media (max-width:375px) {ul.jsx-319a8f7705b11ab1{gap:0 12px}\nli.jsx-319a8f7705b11ab1{width:106px;\nheight:106px}\nh3.jsx-319a8f7705b11ab1{font-size:12px}\na.jsx-319a8f7705b11ab1{padding:8px}}"
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategoriesCardMobile);


/***/ }),

/***/ 3120:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";

// UNUSED EXPORTS: fetchCategories

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
;// CONCATENATED MODULE: ./types/categories.ts
var categories_CategoriesActionTypes;
(function(CategoriesActionTypes) {
    CategoriesActionTypes["FETCH_CATEGORIES_SUCCESS"] = "FETCH_CATEGORIES_SUCCESS";
    CategoriesActionTypes["FETCH_CATEGORIES_ERROR"] = "FETCH_CATEGORIES_ERROR";
})(categories_CategoriesActionTypes || (categories_CategoriesActionTypes = {}));

;// CONCATENATED MODULE: ./store/actions-creators/categories.ts


const fetchCategories = ()=>{
    return async (dispatch)=>{
        try {
            const response = await axios.get('http://localhost:4200/categories');
            dispatch({
                type: CategoriesActionTypes.FETCH_CATEGORIES_SUCCESS,
                payload: response.data
            });
        } catch (error) {
            dispatch({
                type: CategoriesActionTypes.FETCH_CATEGORIES_ERROR,
                payload: "Произошла ошибка при загрузке товаров"
            });
        }
    };
};


/***/ })

};
;