exports.id = 301;
exports.ids = [301];
exports.modules = {

/***/ 1524:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "HeaderMobile_container__WYcSb",
	"wayDeliveryMobile": "HeaderMobile_wayDeliveryMobile__cgSet",
	"wayDeliveryBtnMobile": "HeaderMobile_wayDeliveryBtnMobile__Ddz_K",
	"wrapper": "HeaderMobile_wrapper__JdgcP",
	"navWrapper": "HeaderMobile_navWrapper__aygGx",
	"burger": "HeaderMobile_burger__jLKRb",
	"catalogBtn": "HeaderMobile_catalogBtn__5ReXQ"
};


/***/ }),

/***/ 2486:
/***/ ((module) => {

// Exports
module.exports = {
	"footerFeedbackBtn": "Button_footerFeedbackBtn__l1MMT"
};


/***/ }),

/***/ 7656:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "Footer_footer__Tl1eP",
	"footerContainer": "Footer_footerContainer__nH_FT",
	"copyrightText": "Footer_copyrightText___wp6E",
	"navMenu": "Footer_navMenu__LpuUJ",
	"navMenuLeft": "Footer_navMenuLeft__2fu9i",
	"navMenuRight": "Footer_navMenuRight__Vf2Iv",
	"navLink": "Footer_navLink__uxVWK",
	"footerConatctsWrapper": "Footer_footerConatctsWrapper___v17J",
	"footerContactsSubtitle": "Footer_footerContactsSubtitle__svksk",
	"footerContactsPhone": "Footer_footerContactsPhone__JLZr8",
	"conatctsDuration": "Footer_conatctsDuration__jFN4b",
	"socialLink": "Footer_socialLink__kQcM_",
	"feedbackWrapper": "Footer_feedbackWrapper__byok9",
	"feedbackTitle": "Footer_feedbackTitle__YsQdI",
	"feedbackText": "Footer_feedbackText__QKxdD",
	"copyrightContainer": "Footer_copyrightContainer__VDYoE",
	"copyrightWrapper": "Footer_copyrightWrapper___Hg9C",
	"copyrightYears": "Footer_copyrightYears__kG3is",
	"copirightInfo": "Footer_copirightInfo__PUBAe",
	"siteCreators": "Footer_siteCreators__oXWlF"
};


/***/ }),

/***/ 168:
/***/ ((module) => {

// Exports
module.exports = {
	"mainContainer": "Header_mainContainer__jw_sj",
	"linkWrapper": "Header_linkWrapper__LOMJ0",
	"catalogButton": "Header_catalogButton__UG32l",
	"link": "Header_link__3RNlo",
	"linkClock": "Header_linkClock__QPCxU",
	"basket": "Header_basket__UyKMV",
	"navWrapper": "Header_navWrapper__j_bRC",
	"wayDelivery": "Header_wayDelivery__XOqcm",
	"btnDiliveryWrapper": "Header_btnDiliveryWrapper__Gvtpb",
	"btnDeliveryTitle": "Header_btnDeliveryTitle__hx0Qo",
	"basketLinkWrapper": "Header_basketLinkWrapper__oRB9l",
	"wayDeliveryMobile": "Header_wayDeliveryMobile__WSxZh"
};


/***/ }),

/***/ 1025:
/***/ ((module) => {

// Exports
module.exports = {
	"searchInput": "Input_searchInput__kK7_V",
	"searchInputMobile": "Input_searchInputMobile__iLCT_"
};


/***/ }),

/***/ 1983:
/***/ ((module) => {

// Exports
module.exports = {
	"icon": "InputIcon_icon__Cccft"
};


/***/ }),

/***/ 9180:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Layout_container__S4aNf"
};


/***/ }),

/***/ 5301:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/Footer.module.css
var Footer_module = __webpack_require__(7656);
var Footer_module_default = /*#__PURE__*/__webpack_require__.n(Footer_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./public/logo.png
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.27c1ae36.png","height":46,"width":117,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAbklEQVR4nAFjAJz/ATqhMoCkF+Vnl+4Xp7T6BLY9BP0V+v8B/AAA/xoAAAD6AeG5Fd0aBuwA7PsR+8LzFIOZ9AsCIwP+Cfv/APEAAADnAf/CAJr9/QAzAwMA027iLqrx/wIaBAH/Cf7/AOUAAACuzmMsQcp/c1kAAAAASUVORK5CYII="});
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "styled-jsx/style"
var style_ = __webpack_require__(9816);
var style_default = /*#__PURE__*/__webpack_require__.n(style_);
// EXTERNAL MODULE: ./styles/Button.module.css
var Button_module = __webpack_require__(2486);
var Button_module_default = /*#__PURE__*/__webpack_require__.n(Button_module);
;// CONCATENATED MODULE: ./components/common/Button.tsx



const Button = ({ title , styleName , isCatalog  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
        className: "jsx-beb68726ae84291a" + " " + ((Button_module_default())[styleName] || ""),
        children: [
            title,
            isCatalog && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                width: "17",
                height: "12",
                viewBox: "0 0 17 12",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                className: "jsx-beb68726ae84291a",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: "17",
                        height: "2",
                        rx: "1",
                        fill: "white",
                        className: "jsx-beb68726ae84291a"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        y: "5",
                        width: "17",
                        height: "2",
                        rx: "1",
                        fill: "white",
                        className: "jsx-beb68726ae84291a"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        y: "10",
                        width: "17",
                        height: "2",
                        rx: "1",
                        fill: "white",
                        className: "jsx-beb68726ae84291a"
                    })
                ]
            }),
            jsx_runtime_.jsx((style_default()), {
                id: "beb68726ae84291a",
                children: "svg.jsx-beb68726ae84291a{margin-left:35px}"
            })
        ]
    }));
};
/* harmony default export */ const common_Button = (Button);

;// CONCATENATED MODULE: ./components/Footer.tsx






const Footer = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Footer_module_default()).footer,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Footer_module_default()).footerContainer,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                            layout: "fixed",
                            src: logo,
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                        className: (Footer_module_default()).navMenu,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Footer_module_default()).navMenuLeft,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: (Footer_module_default()).navLink,
                                            children: "Каталог товаров"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: (Footer_module_default()).navLink,
                                            children: "Акции"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: (Footer_module_default()).navLink,
                                            children: "Собственные марки"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Footer_module_default()).navMenuRight,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: (Footer_module_default()).navLink,
                                            children: "Контакты"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: (Footer_module_default()).navLink,
                                            children: "Активация карты"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: (Footer_module_default()).navLink,
                                            children: "Личный кабинет"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Footer_module_default()).footerConatctsWrapper,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (Footer_module_default()).footerContactsSubtitle,
                                children: "Служба поддержки"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: (Footer_module_default()).footerContactsPhone,
                                href: "tel:88007009745",
                                children: "8 800 700-97-45"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (Footer_module_default()).conatctsDuration,
                                children: "Ежедневно 8:00 - 23:00"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: (Footer_module_default()).socialLink,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                width: "40",
                                                height: "40",
                                                viewBox: "0 0 40 40",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                                        width: "40",
                                                        height: "40",
                                                        rx: "20",
                                                        fill: "#F2F5FB"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        fillRule: "evenodd",
                                                        clipRule: "evenodd",
                                                        d: "M16.622 13.25H23.3788C25.2403 13.25 26.75 14.759 26.75 16.622V23.3788C26.75 25.2403 25.241 26.75 23.378 26.75H16.622C14.7597 26.75 13.25 25.241 13.25 23.378V16.622C13.25 14.7597 14.759 13.25 16.622 13.25V13.25Z",
                                                        stroke: "#304250",
                                                        strokeWidth: "1.5",
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        d: "M23.7106 16.035C23.5711 16.0357 23.4578 16.149 23.4578 16.2885C23.4578 16.428 23.5718 16.5412 23.7113 16.5412C23.8508 16.5412 23.9641 16.428 23.9641 16.2885C23.9648 16.1482 23.8508 16.035 23.7106 16.035",
                                                        stroke: "#304250",
                                                        strokeWidth: "1.5",
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        d: "M21.909 18.0906C22.9634 19.145 22.9634 20.8546 21.909 21.909C20.8546 22.9634 19.145 22.9634 18.0906 21.909C17.0362 20.8546 17.0362 19.145 18.0906 18.0906C19.145 17.0362 20.8546 17.0362 21.909 18.0906",
                                                        stroke: "#304250",
                                                        strokeWidth: "1.5",
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round"
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: (Footer_module_default()).socialLink,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                width: "40",
                                                height: "40",
                                                viewBox: "0 0 40 40",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                                        width: "40",
                                                        height: "40",
                                                        rx: "20",
                                                        fill: "#F2F5FB"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        d: "M23.728 26.501V21.6161H25.3824L25.6299 19.7119H23.728V18.4969C23.728 17.9451 23.8831 17.5697 24.6801 17.5697L25.6962 17.5685V15.8656C25.5197 15.8419 24.917 15.791 24.2147 15.791C22.7487 15.791 21.7456 16.678 21.7456 18.3075V19.7119L20.2891 19.7072V21.6114L21.7456 21.6161V26.5022H23.728V26.501Z",
                                                        fill: "#304250"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        fillRule: "evenodd",
                                                        clipRule: "evenodd",
                                                        d: "M17.622 13.25H24.3788C26.2403 13.25 27.75 14.759 27.75 16.622V23.3788C27.75 25.2403 26.241 26.75 24.378 26.75H17.622C15.7597 26.75 14.25 25.241 14.25 23.378V16.622C14.25 14.7597 15.759 13.25 17.622 13.25V13.25Z",
                                                        stroke: "#304250",
                                                        strokeWidth: "1.5",
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round"
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: (Footer_module_default()).socialLink,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                width: "40",
                                                height: "40",
                                                viewBox: "0 0 40 40",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                                        width: "40",
                                                        height: "40",
                                                        rx: "20",
                                                        fill: "#F2F5FB"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        d: "M28.1613 24.2002C27.4874 22.9875 25.7515 21.5302 25.0349 20.8961C24.8388 20.7225 24.8178 20.4221 24.9963 20.2301C26.3639 18.7605 27.4578 17.0718 27.8343 16.0515C28.0004 15.6007 27.6565 15.1245 27.172 15.1245H25.7646C25.3008 15.1245 25.0293 15.291 24.8999 15.5561C23.7633 17.8852 22.7883 18.8932 22.1058 19.4823C21.7236 19.8123 21.1278 19.539 21.1278 19.0368C21.1278 18.0693 21.1278 16.8187 21.1278 15.9318C21.1278 15.5017 20.776 15.1537 20.3421 15.1537L17.7711 15.1245C17.4475 15.1245 17.2626 15.4908 17.4569 15.7477L17.8814 16.3571C18.0411 16.5682 18.1274 16.8251 18.1274 17.0887L18.1251 19.833C18.1251 20.3103 17.5465 20.5436 17.203 20.2091C16.0409 19.0773 15.0325 16.7662 14.6695 15.6611C14.5645 15.3412 14.2649 15.1252 13.9251 15.1245L12.5388 15.1211C12.0186 15.1211 11.6384 15.6142 11.7798 16.1107C13.0465 20.5571 15.6456 24.7871 20.2776 25.2457C20.734 25.2907 21.1278 24.9232 21.1278 24.4683V23.0261C21.1278 22.6125 21.4521 22.257 21.8691 22.2465C21.8838 22.2461 21.8984 22.2461 21.913 22.2461C23.1381 22.2461 24.5103 24.0292 24.9903 24.8632C25.1283 25.1032 25.3863 25.2495 25.6653 25.2495H27.5301C28.0743 25.2495 28.4234 24.6723 28.1613 24.2002Z",
                                                        fill: "#304250"
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Footer_module_default()).feedbackWrapper,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: (Footer_module_default()).feedbackTitle,
                                children: "Вопросы и предложения"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (Footer_module_default()).feedbackText,
                                children: "С вашей помощью мы становимся лучше"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(common_Button, {
                                title: "Напишите нам",
                                styleName: "footerFeedbackBtn"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Footer_module_default()).copyrightContainer,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Footer_module_default()).copyrightWrapper,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (Footer_module_default()).copyrightYears,
                                children: "\xa9 2005—2022 ООО \xabЧелныХлеб\xbb."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (Footer_module_default()).copirightInfo,
                                children: "Правовая информация"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (Footer_module_default()).siteCreators,
                        children: "Разработка сайта"
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const components_Footer = (Footer);

// EXTERNAL MODULE: ./styles/Header.module.css
var Header_module = __webpack_require__(168);
var Header_module_default = /*#__PURE__*/__webpack_require__.n(Header_module);
// EXTERNAL MODULE: ./styles/Input.module.css
var Input_module = __webpack_require__(1025);
var Input_module_default = /*#__PURE__*/__webpack_require__.n(Input_module);
// EXTERNAL MODULE: ./styles/InputIcon.module.css
var InputIcon_module = __webpack_require__(1983);
var InputIcon_module_default = /*#__PURE__*/__webpack_require__.n(InputIcon_module);
;// CONCATENATED MODULE: ./components/common/input/InputIcon.tsx


const InputIcon = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        className: (InputIcon_module_default()).icon,
        width: "20",
        height: "20",
        viewBox: "0 0 20 20",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                cx: "9.21503",
                cy: "9.21503",
                r: "5.88495",
                stroke: "#B0BCC9",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M16.668 16.668L13.375 13.375",
                stroke: "#B0BCC9",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            })
        ]
    }));
};
/* harmony default export */ const input_InputIcon = (InputIcon);

;// CONCATENATED MODULE: ./components/common/input/Input.tsx



const Input = ({ name , styleName , type , hasIcon  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        style: {
            position: "relative",
            flex: "1 1 auto"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                className: (Input_module_default())[styleName],
                placeholder: name,
                type: type
            }),
            hasIcon && /*#__PURE__*/ jsx_runtime_.jsx(input_InputIcon, {})
        ]
    }));
};
/* harmony default export */ const input_Input = (Input);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-responsive"
var external_react_responsive_ = __webpack_require__(6666);
;// CONCATENATED MODULE: ./public/logoMobile.png
/* harmony default export */ const logoMobile = ({"src":"/_next/static/media/logoMobile.a7b141c7.png","height":36,"width":90,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAbklEQVR4nAFjAJz/AT2hMoGhF+Rmm+4XqrD6BbM8BP0X+/8B+QAA/xsAAAD+AeO5FN4YBu3+7vsQ/cLzFYSW9AsAJAP+Cvv/APAAAADnAf/CAJL9/QA1AwMA0m3iL67y/wEZBAD/C/4BAOUAAACwAkEsRjwnvm0AAAAASUVORK5CYII="});
// EXTERNAL MODULE: ./components/mobile/HeaderMobile.module.css
var HeaderMobile_module = __webpack_require__(1524);
var HeaderMobile_module_default = /*#__PURE__*/__webpack_require__.n(HeaderMobile_module);
;// CONCATENATED MODULE: ./components/mobile/HeaderMobile.jsx






const HeaderMobile = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (HeaderMobile_module_default()).wayDeliveryMobile,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                    className: (HeaderMobile_module_default()).wayDeliveryBtnMobile,
                    children: [
                        "Выберите способ получения",
                        /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            width: "7",
                            height: "11",
                            viewBox: "0 0 7 11",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M1.4165 9.84961L5.58317 5.47461L1.4165 1.09961",
                                stroke: "#B0BCC9",
                                strokeWidth: "1.5",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (HeaderMobile_module_default()).container,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (HeaderMobile_module_default()).wrapper,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (HeaderMobile_module_default()).navWrapper,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: (HeaderMobile_module_default()).burger
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                            layout: "fixed",
                                            src: logoMobile,
                                            alt: ""
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                    className: (HeaderMobile_module_default()).catalogBtn,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            width: "16",
                                            height: "17",
                                            viewBox: "0 0 16 17",
                                            fill: "none",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    fillRule: "evenodd",
                                                    clipRule: "evenodd",
                                                    d: "M4.66667 6.33333H2.16667C1.24583 6.33333 0.5 5.5875 0.5 4.66667V2.16667C0.5 1.24583 1.24583 0.5 2.16667 0.5H4.66667C5.5875 0.5 6.33333 1.24583 6.33333 2.16667V4.66667C6.33333 5.5875 5.5875 6.33333 4.66667 6.33333Z",
                                                    fill: "white",
                                                    stroke: "white",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    fillRule: "evenodd",
                                                    clipRule: "evenodd",
                                                    d: "M13.8327 6.33333H11.3327C10.4118 6.33333 9.66602 5.5875 9.66602 4.66667V2.16667C9.66602 1.24583 10.4118 0.5 11.3327 0.5H13.8327C14.7535 0.5 15.4993 1.24583 15.4993 2.16667V4.66667C15.4993 5.5875 14.7535 6.33333 13.8327 6.33333Z",
                                                    fill: "white",
                                                    stroke: "white",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    fillRule: "evenodd",
                                                    clipRule: "evenodd",
                                                    d: "M13.8327 15.5033H11.3327C10.4118 15.5033 9.66602 14.7574 9.66602 13.8366V11.3366C9.66602 10.4158 10.4118 9.66992 11.3327 9.66992H13.8327C14.7535 9.66992 15.4993 10.4158 15.4993 11.3366V13.8366C15.4993 14.7574 14.7535 15.5033 13.8327 15.5033Z",
                                                    fill: "white",
                                                    stroke: "white",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    fillRule: "evenodd",
                                                    clipRule: "evenodd",
                                                    d: "M4.66667 15.4994H2.16667C1.24583 15.4994 0.5 14.7535 0.5 13.8327V11.3327C0.5 10.4118 1.24583 9.66602 2.16667 9.66602H4.66667C5.5875 9.66602 6.33333 10.4118 6.33333 11.3327V13.8327C6.33333 14.7535 5.5875 15.4994 4.66667 15.4994Z",
                                                    fill: "white",
                                                    stroke: "white",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                })
                                            ]
                                        }),
                                        "Каталог"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                    width: "26",
                                    height: "26",
                                    viewBox: "0 0 26 26",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M6.46614 7.17529L5.74356 3.92529H3.65381",
                                            stroke: "#B0BCC9",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            fillRule: "evenodd",
                                            clipRule: "evenodd",
                                            d: "M8.37563 16.0695L6.4668 7.17529H20.1796C20.8697 7.17529 21.3832 7.81121 21.2391 8.48613L19.612 16.0695C19.5047 16.5689 19.0638 16.9253 18.5525 16.9253H9.43405C8.9238 16.9253 8.48288 16.5689 8.37563 16.0695Z",
                                            stroke: "#B0BCC9",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M18.7178 20.4743C18.3949 20.4743 18.1328 20.7364 18.1359 21.0593C18.1359 21.3822 18.398 21.6443 18.7209 21.6443C19.0438 21.6443 19.3059 21.3822 19.3059 21.0593C19.3044 20.7364 19.0423 20.4743 18.7178 20.4743",
                                            stroke: "#B0BCC9",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M9.83187 20.4743C9.50895 20.4743 9.24687 20.7364 9.24999 21.0593C9.24843 21.3822 9.51051 21.6443 9.83343 21.6443C10.1563 21.6443 10.4184 21.3822 10.4184 21.0593C10.4184 20.7364 10.1563 20.4743 9.83187 20.4743",
                                            stroke: "#B0BCC9",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                    width: "20",
                                    height: "22",
                                    viewBox: "0 0 20 22",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M12.6813 2.90206C14.162 4.3828 14.162 6.78355 12.6813 8.26429C11.2005 9.74503 8.7998 9.74503 7.31905 8.26429C5.83831 6.78355 5.83831 4.3828 7.31905 2.90206C8.7998 1.42132 11.2005 1.42132 12.6813 2.90206",
                                            stroke: "#B0BCC9",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            fillRule: "evenodd",
                                            clipRule: "evenodd",
                                            d: "M1.3335 18.0413V19.1246C1.3335 19.7226 1.81883 20.208 2.41683 20.208H17.5835C18.1815 20.208 18.6668 19.7226 18.6668 19.1246V18.0413C18.6668 14.7631 14.3855 12.6333 10.0002 12.6333C5.61483 12.6333 1.3335 14.7631 1.3335 18.0413Z",
                                            stroke: "#B0BCC9",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(input_Input, {
                                styleName: "searchInputMobile",
                                name: "Поиск по каталогу",
                                type: "text",
                                hasIcon: true
                            })
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const mobile_HeaderMobile = (HeaderMobile);

;// CONCATENATED MODULE: ./components/Header.tsx










const Header = ()=>{
    const router = (0,router_.useRouter)();
    const isMobile = (0,external_react_responsive_.useMediaQuery)({
        query: '(max-width: 480px)'
    });
    return(/*#__PURE__*/ jsx_runtime_.jsx("header", {
        className: (Header_module_default()).mainContainer,
        /*#__PURE__*/ children: isMobile ? /*#__PURE__*/ jsx_runtime_.jsx(mobile_HeaderMobile, {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (Header_module_default()).linkWrapper,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/catalog/baker",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: (Header_module_default()).link,
                                        children: "Мудрый пекарь"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/catalog/citchen",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: (Header_module_default()).link,
                                        children: "Домашняя кухня"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "#",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: (Header_module_default()).link,
                                        children: "Халяль"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: (Header_module_default()).linkClock,
                                    children: "часы работы: 9.00 - 22.00"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: (Header_module_default()).link,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "tel:88007009745",
                                        children: "8 800 700 97 45"
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (Header_module_default()).navWrapper,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    layout: "fixed",
                                    src: logo,
                                    alt: ""
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                            onClick: ()=>router.push('/catalog')
                            ,
                            className: "jsx-d74e1546a0fea84a" + " " + ((Header_module_default()).catalogButton || ""),
                            children: [
                                "каталог",
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                    width: "17",
                                    height: "12",
                                    viewBox: "0 0 17 12",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    className: "jsx-d74e1546a0fea84a",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                            width: "17",
                                            height: "2",
                                            rx: "1",
                                            fill: "white",
                                            className: "jsx-d74e1546a0fea84a"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                            y: "5",
                                            width: "17",
                                            height: "2",
                                            rx: "1",
                                            fill: "white",
                                            className: "jsx-d74e1546a0fea84a"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                            y: "10",
                                            width: "17",
                                            height: "2",
                                            rx: "1",
                                            fill: "white",
                                            className: "jsx-d74e1546a0fea84a"
                                        })
                                    ]
                                }),
                                jsx_runtime_.jsx((style_default()), {
                                    id: "d74e1546a0fea84a",
                                    children: "svg.jsx-d74e1546a0fea84a{margin-left:35px;\nmargin-bottom:20px}\n@media (max-width:930px) {svg.jsx-d74e1546a0fea84a{display:none}}"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(input_Input, {
                            styleName: "searchInput",
                            name: "Поиск по каталогу",
                            type: "text",
                            hasIcon: true
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: (Header_module_default()).wayDelivery,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Header_module_default()).btnDiliveryWrapper,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        width: "15",
                                        height: "15",
                                        viewBox: "0 0 15 15",
                                        fill: "none",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            fillRule: "evenodd",
                                            clipRule: "evenodd",
                                            d: "M9.84519 13.3127L13.9072 2.35371C14.2052 1.54971 13.4222 0.766715 12.6182 1.06471L1.65419 5.12971C0.730187 5.47271 0.803187 6.80272 1.75819 7.04272L6.69819 8.28371L7.93119 13.2077C8.17119 14.1637 9.50219 14.2367 9.84519 13.3127V13.3127Z",
                                            stroke: "#61A430",
                                            strokeWidth: "1.5",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (Header_module_default()).btnDeliveryTitle,
                                        children: "Выберите способ получения"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        width: "8",
                                        height: "12",
                                        viewBox: "0 0 8 12",
                                        fill: "none",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M1.66699 10.6668L6.33366 6.00016L1.66699 1.3335",
                                            stroke: "#61A430",
                                            strokeWidth: "1.5",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (Header_module_default()).basketLinkWrapper,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/basket",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: (Header_module_default()).basket,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            width: "20",
                                            height: "20",
                                            viewBox: "0 0 20 20",
                                            fill: "none",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M4.97388 5.51953L4.41805 3.01953H2.81055",
                                                    stroke: "#B0BCC9",
                                                    strokeWidth: "1.5",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    fillRule: "evenodd",
                                                    clipRule: "evenodd",
                                                    d: "M6.44294 12.3612L4.97461 5.51953H15.5229C16.0538 5.51953 16.4488 6.0087 16.3379 6.52786L15.0863 12.3612C15.0038 12.7454 14.6646 13.0195 14.2713 13.0195H7.25711C6.86461 13.0195 6.52544 12.7454 6.44294 12.3612Z",
                                                    stroke: "#B0BCC9",
                                                    strokeWidth: "1.5",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M14.3984 15.7496C14.15 15.7496 13.9484 15.9512 13.9508 16.1996C13.9508 16.448 14.1524 16.6496 14.4008 16.6496C14.6492 16.6496 14.8508 16.448 14.8508 16.1996C14.8496 15.9512 14.648 15.7496 14.3984 15.7496",
                                                    stroke: "#B0BCC9",
                                                    strokeWidth: "1.5",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M7.56305 15.7496C7.31465 15.7496 7.11305 15.9512 7.11545 16.1996C7.11425 16.448 7.31585 16.6496 7.56425 16.6496C7.81265 16.6496 8.01425 16.448 8.01425 16.1996C8.01425 15.9512 7.81265 15.7496 7.56305 15.7496",
                                                    stroke: "#B0BCC9",
                                                    strokeWidth: "1.5",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/account/favorities",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: (Header_module_default()).basket,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                            width: "20",
                                            height: "20",
                                            viewBox: "0 0 20 20",
                                            fill: "none",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                fillRule: "evenodd",
                                                clipRule: "evenodd",
                                                d: "M13.08 3.33203C15.7258 3.33203 17.5 5.81536 17.5 8.12786C17.5 12.822 10.1342 16.6654 10 16.6654C9.86583 16.6654 2.5 12.822 2.5 8.12786C2.5 5.81536 4.27417 3.33203 6.92 3.33203C8.4325 3.33203 9.42583 4.0862 10 4.75786C10.5742 4.0862 11.5675 3.33203 13.08 3.33203Z",
                                                stroke: "#B0BCC9",
                                                strokeWidth: "1.5",
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round"
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/account/thisorder",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: (Header_module_default()).basket,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            width: "20",
                                            height: "20",
                                            viewBox: "0 0 20 20",
                                            fill: "none",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M12.0621 3.77078C13.2011 4.90981 13.2011 6.75654 12.0621 7.89557C10.923 9.0346 9.07632 9.0346 7.93728 7.89557C6.79825 6.75654 6.79825 4.90981 7.93728 3.77078C9.07632 2.63175 10.923 2.63175 12.0621 3.77078",
                                                    stroke: "#B0BCC9",
                                                    strokeWidth: "1.5",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    fillRule: "evenodd",
                                                    clipRule: "evenodd",
                                                    d: "M3.33301 15.4163V16.2497C3.33301 16.7097 3.70634 17.083 4.16634 17.083H15.833C16.293 17.083 16.6663 16.7097 16.6663 16.2497V15.4163C16.6663 12.8947 13.373 11.2563 9.99967 11.2563C6.62634 11.2563 3.33301 12.8947 3.33301 15.4163Z",
                                                    stroke: "#B0BCC9",
                                                    strokeWidth: "1.5",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                })
                                            ]
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const components_Header = (Header);

// EXTERNAL MODULE: ./styles/Layout.module.css
var Layout_module = __webpack_require__(9180);
var Layout_module_default = /*#__PURE__*/__webpack_require__.n(Layout_module);
;// CONCATENATED MODULE: ./components/Layout.tsx




function Layout({ children  }) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components_Header, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: (Layout_module_default()).container,
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Footer, {})
        ]
    }));
};


/***/ })

};
;