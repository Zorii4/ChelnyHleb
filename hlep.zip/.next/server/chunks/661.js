exports.id = 661;
exports.ids = [661];
exports.modules = {

/***/ 5112:
/***/ ((module) => {

// Exports
module.exports = {
	"puchaseWrapper": "OrderAmount_puchaseWrapper___hNM9",
	"puchaseListItem": "OrderAmount_puchaseListItem__vwIlT",
	"puchaseTitle": "OrderAmount_puchaseTitle___uQng",
	"puchaseNumber": "OrderAmount_puchaseNumber__QQ_zX",
	"puchaseGoods": "OrderAmount_puchaseGoods__UJGnX",
	"puchaseDiscount": "OrderAmount_puchaseDiscount__Yjryj",
	"puchaseBonuses": "OrderAmount_puchaseBonuses__IyiDZ",
	"puchaseNumberBonus": "OrderAmount_puchaseNumberBonus__B5Xja",
	"puchaseAdressWrapper": "OrderAmount_puchaseAdressWrapper__M_mrY",
	"deliveryWrapper": "OrderAmount_deliveryWrapper__1u9n5",
	"deliveryTitle": "OrderAmount_deliveryTitle__YXgOH",
	"address": "OrderAmount_address__OJl3x",
	"time": "OrderAmount_time__gp0e3",
	"changeAddressLink": "OrderAmount_changeAddressLink__GmYYu",
	"kindOfDeliveryWrapper": "OrderAmount_kindOfDeliveryWrapper__8ZLEN",
	"freeDeliveryText": "OrderAmount_freeDeliveryText__iXO4X",
	"puchaseTotalAmount": "OrderAmount_puchaseTotalAmount__D_gqh",
	"puchasePromo": "OrderAmount_puchasePromo__g1p1Q",
	"puchaseButton": "OrderAmount_puchaseButton__Pnqs8"
};


/***/ }),

/***/ 3388:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5112);
/* harmony import */ var _OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);




const OrderAmount = ({ goodsInBasket , address  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseWrapper),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                    className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseListItem),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseTitle),
                            children: "Ваш заказ"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseNumber),
                            children: [
                                goodsInBasket.reduce((acc, good)=>Math.round((acc += good.weight) * 100) / 100
                                , 0),
                                " кг"
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                    className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseListItem),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseGoods),
                            children: [
                                "Товары(",
                                goodsInBasket.length,
                                ")"
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseNumber),
                            children: [
                                goodsInBasket.reduce((acc, good)=>Math.round((acc += good.newprice) * 100) / 100
                                , 0),
                                " ₽"
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                    className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseListItem),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseDiscount),
                            children: "Скидка"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseNumber),
                            children: [
                                goodsInBasket.reduce((acc, good)=>Math.round((acc += good.oldprice) * 100) / 100
                                , 0),
                                " ₽"
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                    className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseListItem),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseBonuses),
                            children: "Вернется бонусов"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseNumberBonus),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                    width: "16",
                                    height: "16",
                                    viewBox: "0 0 16 16",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            fillRule: "evenodd",
                                            clipRule: "evenodd",
                                            d: "M4.39392 7.80187C3.32937 6.72936 2.0368 6.03646 0.507812 5.72866C1.3972 2.62076 4.06229 0.316157 7.26582 0.00849149C5 2.5 3.92885 5.42885 4.39392 7.80187ZM8.6367 0C11.9133 0.271225 14.5936 2.60596 15.4919 5.70762C13.9369 5.99834 12.5915 6.70941 11.5 7.80187C12.0543 5.44567 11 2.5 8.6367 0Z",
                                            fill: "#61A430"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            fillRule: "evenodd",
                                            clipRule: "evenodd",
                                            d: "M0.204489 6.24544C-0.929492 11.1058 2.79718 15.8919 7.81063 16C8.03383 11.2589 4.40682 7.76016 0.204489 6.24544ZM4.90362 6.77021C4.90313 4.24661 6.38411 1.91193 7.90625 0C7.92139 0 7.92139 0 7.93434 0C9.48957 1.87246 11.085 4.25262 11.085 6.77021C11.085 8.52794 9.90465 10.6493 7.92139 10.6493C5.9616 10.6493 4.90362 8.46504 4.90362 6.77021ZM8.17795 16C13.1637 15.8893 16.9524 11.099 15.7882 6.24544C11.5787 7.74257 7.95425 11.2645 8.17795 16Z",
                                            fill: "#61A430"
                                        })
                                    ]
                                }),
                                "37"
                            ]
                        })
                    ]
                }),
                address ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                            className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseAdressWrapper),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().deliveryWrapper),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().deliveryTitle),
                                            children: "Доставка"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseNumber),
                                            children: "0 ₽"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().address),
                                    children: "Address to Delivery"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().time),
                                    children: "Time to Delivery"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                    href: "#",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().changeAddressLink),
                                        children: "Изменить"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                            className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().kindOfDeliveryWrapper),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                    width: "10",
                                    height: "8",
                                    viewBox: "0 0 10 8",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        d: "M9 1.25L3.5 6.75L1 4.25",
                                        stroke: "#304250",
                                        strokeWidth: "1.5",
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().freeDeliveryText),
                                    children: "Бесплатная доставка от Мудрого Пекаря"
                                })
                            ]
                        })
                    ]
                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().deliveryWrapper),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().deliveryTitle),
                            children: "Доставка"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseNumber),
                            children: "0 ₽"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                    className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseListItem),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Итого к оплате"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseTotalAmount),
                            children: "1270"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchasePromo),
                        placeholder: "Промокод"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: (_OrderAmount_module_css__WEBPACK_IMPORTED_MODULE_3___default().puchaseButton),
                        onClick: ()=>router.push('/order')
                        ,
                        children: "Перейти к оформлению"
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OrderAmount);


/***/ })

};
;