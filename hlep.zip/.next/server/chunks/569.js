exports.id = 569;
exports.ids = [569];
exports.modules = {

/***/ 341:
/***/ ((module) => {

// Exports
module.exports = {
	"mainContainer": "Account_mainContainer__GWEG4",
	"userBonusCardContainer": "Account_userBonusCardContainer__b4xbb",
	"bonusNumberWrapper": "Account_bonusNumberWrapper__uZOso",
	"bonusNumber": "Account_bonusNumber__qqyCo",
	"bonusNumberText": "Account_bonusNumberText__461YA",
	"userBonusCardName": "Account_userBonusCardName__QShfk",
	"userBonusCardNumber": "Account_userBonusCardNumber__fSgog",
	"userLinksContainer": "Account_userLinksContainer__PHhqD",
	"accountListItem": "Account_accountListItem__Q_P_w",
	"accountLink": "Account_accountLink__IBxdX",
	"activeLink": "Account_activeLink__dqH4M"
};


/***/ }),

/***/ 569:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ AccountLayout_AccountLayout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/AccountLayout/Account.module.css
var Account_module = __webpack_require__(341);
var Account_module_default = /*#__PURE__*/__webpack_require__.n(Account_module);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./FAKE_API/goods.js
var goods = __webpack_require__(294);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./components/ActiveLink.jsx




function ActiveLink({ children , activeClassName , defaultClassName , ...rest }) {
    const { asPath  } = (0,router_.useRouter)();
    const className = asPath === rest.href ? activeClassName : defaultClassName;
    return(/*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
        ...rest,
        children: /*#__PURE__*/ (0,external_react_.cloneElement)(children, {
            className
        })
    }));
}

;// CONCATENATED MODULE: ./components/AccountLayout/AccountLayout.jsx






const AccountLayout = ({ children  })=>{
    const { 0: user , 1: setUser  } = (0,external_react_.useState)();
    (0,external_react_.useEffect)(()=>{
        setUser((0,goods/* fetchOneUser */.Gl)());
    }, []);
    if (!user) return(/*#__PURE__*/ jsx_runtime_.jsx("p", {
        children: "loading"
    }));
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (Account_module_default()).mainContainer,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (Account_module_default()).userBonusCardContainer,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (Account_module_default()).bonusNumberWrapper,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: (Account_module_default()).bonusNumber,
                                            children: user.bonus
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: (Account_module_default()).bonusNumberText,
                                            children: "Бонусных баллов"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (Account_module_default()).userBonusCardName,
                                    children: user.name
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: (Account_module_default()).userBonusCardNumber,
                                    children: user.cardNumber
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (Account_module_default()).userLinksContainer,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Account_module_default()).accountListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ActiveLink, {
                                            href: "/account/thisorder",
                                            defaultClassName: (Account_module_default()).accountLink,
                                            activeClassName: (Account_module_default()).activeLink,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Account_module_default()).accountLink,
                                                children: "Текущий заказ"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Account_module_default()).accountListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ActiveLink, {
                                            href: "/account/historyorder",
                                            defaultClassName: (Account_module_default()).accountLink,
                                            activeClassName: (Account_module_default()).activeLink,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Account_module_default()).accountLink,
                                                children: "История заказов"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Account_module_default()).accountListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ActiveLink, {
                                            href: "/account/favorities",
                                            defaultClassName: (Account_module_default()).accountLink,
                                            activeClassName: (Account_module_default()).activeLink,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Account_module_default()).accountLink,
                                                children: "Избранное"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: (Account_module_default()).accountListItem,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ActiveLink, {
                                            href: "/account/settings",
                                            defaultClassName: (Account_module_default()).accountLink,
                                            activeClassName: (Account_module_default()).activeLink,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (Account_module_default()).accountLink,
                                                children: "Мои настройки"
                                            })
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: children
                })
            ]
        })
    }));
};
/* harmony default export */ const AccountLayout_AccountLayout = (AccountLayout);


/***/ })

};
;