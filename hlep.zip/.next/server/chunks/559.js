"use strict";
exports.id = 559;
exports.ids = [559];
exports.modules = {

/***/ 6529:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export useTypedSelector */
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_0__);

const useTypedSelector = (/* unused pure expression or super */ null && (useSelector));


/***/ }),

/***/ 436:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony exports fetchGoods, fetchGoodsFromCategory */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _types_goods__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5784);


const fetchGoods = ()=>{
    return async (dispatch)=>{
        try {
            const response = await axios.get('http://localhost:4200/goods', {
                params: {
                    _limit: 5
                }
            });
            dispatch({
                type: GoodsActionTypes.FETCH_GOODS_SUCCESS,
                payload: response.data
            });
        } catch (error) {
            dispatch({
                type: GoodsActionTypes.FETCH_GOODS_ERROR,
                payload: "Произошла ошибка при загрузке товаров"
            });
        }
    };
};
const fetchGoodsFromCategory = (category)=>{
    return async (dispatch)=>{
        try {
            const response = await axios.get(`http://localhost:4200/goods?category=${category}`);
            dispatch({
                type: GoodsActionTypes.FETCH_GOOD_FROM_CATEGORY_SUCCESS,
                payload: response.data
            });
        } catch (error) {
            dispatch({
                type: GoodsActionTypes.FETCH_GOOD_FROM_CATEGORY_ERROR,
                payload: "Произошла ошибка при загрузке товаров"
            });
        }
    };
};


/***/ }),

/***/ 4664:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "YS": () => (/* binding */ wrapper)
/* harmony export */ });
/* unused harmony exports makeStore, store */
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5648);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _reducers_basketReducer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5609);
/* harmony import */ var _reducers_goodsReducer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5804);




function makeStore() {
    return (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.configureStore)({
        reducer: {
            goodInBasket: _reducers_basketReducer__WEBPACK_IMPORTED_MODULE_2__/* .goodInBasketReducer */ .lH,
            marketGoods: _reducers_goodsReducer__WEBPACK_IMPORTED_MODULE_3__/* .marketGoodsReducer */ .uf
        },
        devTools: true
    });
}
const store = makeStore();
const wrapper = (0,next_redux_wrapper__WEBPACK_IMPORTED_MODULE_0__.createWrapper)(makeStore);


/***/ })

};
;